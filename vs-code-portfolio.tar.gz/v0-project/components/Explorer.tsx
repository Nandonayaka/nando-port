'use client'

import { ChevronDown, Folder, MoreVertical } from 'lucide-react'
import { useState } from 'react'

export default function Explorer() {
  const [folderOpen, setFolderOpen] = useState(true)

  return (
    <div className="w-56 bg-[#252526] border-r border-[#3e3e42] flex flex-col overflow-hidden">
      {/* Header */}
      <div className="px-4 py-3 border-b border-[#3e3e42] flex items-center justify-between flex-shrink-0">
        <h3 className="text-xs font-semibold text-[#cccccc] uppercase tracking-wider">EXPLORER</h3>
        <MoreVertical size={16} className="text-[#858585] cursor-pointer hover:text-[#cccccc]" />
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto">
        {/* Project Folder */}
        <div className="px-2 py-1">
          <div
            className="flex items-center gap-1.5 px-2 py-1.5 hover:bg-[#2d2d30] rounded cursor-pointer group"
            onClick={() => setFolderOpen(!folderOpen)}
          >
            <ChevronDown
              size={16}
              className={`text-[#858585] transition-transform flex-shrink-0 ${!folderOpen ? '-rotate-90' : ''}`}
            />
            <Folder size={16} className="text-[#dcb939] flex-shrink-0" />
            <span className="text-sm text-[#0098ff] hover:text-[#0db7ff] font-medium">NANDO-PORT</span>
          </div>

          {folderOpen && (
            <div className="ml-0 space-y-0">
              <div className="pl-6 pr-2 py-1.5 text-sm text-[#858585] hover:text-[#cccccc] hover:bg-[#2d2d30] rounded cursor-pointer">
                src
              </div>
              <div className="pl-6 pr-2 py-1.5 text-sm text-[#858585] hover:text-[#cccccc] hover:bg-[#2d2d30] rounded cursor-pointer">
                public
              </div>
              <div className="pl-6 pr-2 py-1.5 text-sm text-[#858585] hover:text-[#cccccc] hover:bg-[#2d2d30] rounded cursor-pointer">
                components
              </div>
              <div className="pl-6 pr-2 py-1.5 text-sm text-[#858585] hover:text-[#cccccc] hover:bg-[#2d2d30] rounded cursor-pointer">
                package.json
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
