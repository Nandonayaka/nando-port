'use client'

import { X, FileText, FolderOpen, Folder, GitBranch, Zap } from 'lucide-react'
import { useState } from 'react'

export default function Editor() {
  const [activeTab, setActiveTab] = useState('welcome')

  const startItems = [
    { label: 'New File...', icon: '📄' },
    { label: 'Open File...', icon: '📁' },
    { label: 'Open Folder...', icon: '📂' },
    { label: 'Clone Git Repository...', icon: '⎇' },
    { label: 'Connect to...', icon: '⌘' },
  ]

  const walkthroughs = [
    {
      title: 'Get Started with VS Code',
      description: 'Discover the best customizations to make VS Code yours.',
      icon: '✨',
      progress: 65,
    },
    {
      title: 'Learn the Fundamentals',
      icon: '💡',
    },
    {
      title: 'Boost your Productivity',
      icon: '⚡',
    },
  ]

  const recentProjects = [
    { name: 'Portfolio', path: 'D:\\coding' },
    { name: 'rara-v3-fastapi', path: 'D:\\' },
    { name: 'laravel-agentoo', path: 'D:\\coding' },
    { name: 'c', path: 'D:\\coding\\codingnando' },
    { name: 'fortuna-core', path: 'D:\\coding' },
  ]

  return (
    <div className="flex-1 flex flex-col bg-[#1e1e1e] overflow-hidden">
      {/* Tab Bar */}
      <div className="bg-[#252526] border-b border-[#3e3e42] flex items-center px-2 flex-shrink-0">
        <div
          className={`px-4 py-3 text-sm font-medium flex items-center gap-2.5 border-b-2 cursor-pointer group transition-colors ${
            activeTab === 'welcome'
              ? 'border-[#0098ff] text-[#cccccc]'
              : 'border-transparent text-[#858585] hover:text-[#cccccc]'
          }`}
          onClick={() => setActiveTab('welcome')}
        >
          <div className="w-2 h-2 bg-[#0098ff] rounded-full" />
          <span>Welcome</span>
          <X size={14} className="ml-auto opacity-0 group-hover:opacity-100 transition-opacity" />
        </div>
      </div>

      {/* Content Area */}
      <div className="flex-1 overflow-y-auto">
        <div className="p-12 max-w-5xl">
          {/* Header */}
          <div className="mb-12">
            <h1 className="text-6xl font-light text-[#cccccc] mb-3 tracking-tight">Visual Studio Code</h1>
            <p className="text-lg text-[#858585]">Editing evolved</p>
          </div>

          {/* Main Grid */}
          <div className="grid grid-cols-2 gap-16">
            {/* Start Section */}
            <div>
              <h2 className="text-sm font-semibold text-[#cccccc] mb-6 uppercase tracking-wide">Start</h2>
              <div className="space-y-3">
                {startItems.map((item, idx) => (
                  <div
                    key={idx}
                    className="flex items-center gap-3 text-[#0098ff] hover:text-[#0db7ff] cursor-pointer group transition-colors"
                  >
                    <span className="text-base">{item.icon}</span>
                    <span className="text-sm font-medium group-hover:underline">{item.label}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Walkthroughs Section */}
            <div>
              <h2 className="text-sm font-semibold text-[#cccccc] mb-6 uppercase tracking-wide">Walkthroughs</h2>
              <div className="space-y-3">
                {walkthroughs.map((item, idx) => (
                  <div
                    key={idx}
                    className="bg-[#252526] border border-[#3e3e42] rounded p-4 hover:border-[#0098ff] cursor-pointer transition-colors group"
                  >
                    <div className="flex items-start gap-3 mb-2">
                      <span className="text-base flex-shrink-0">{item.icon}</span>
                      <div>
                        <h3 className="text-sm font-semibold text-[#cccccc] group-hover:text-[#0098ff] transition-colors">
                          {item.title}
                        </h3>
                        {item.description && (
                          <p className="text-xs text-[#858585] mt-1">{item.description}</p>
                        )}
                      </div>
                    </div>
                    {item.progress !== undefined && (
                      <div className="mt-3 h-1 bg-[#3e3e42] rounded-full overflow-hidden">
                        <div
                          className="h-full bg-[#0098ff] rounded-full"
                          style={{ width: `${item.progress}%` }}
                        />
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Recent Section */}
          <div className="mt-12">
            <h2 className="text-sm font-semibold text-[#cccccc] mb-4 uppercase tracking-wide">Recent</h2>
            <div className="space-y-1">
              {recentProjects.map((project, idx) => (
                <div
                  key={idx}
                  className="flex justify-between items-center px-3 py-2 text-sm hover:bg-[#2d2d30] rounded cursor-pointer transition-colors group"
                >
                  <span className="text-[#0098ff] group-hover:text-[#0db7ff] font-medium">{project.name}</span>
                  <span className="text-[#858585] text-xs">{project.path}</span>
                </div>
              ))}
              <div className="px-3 py-2 text-sm text-[#0098ff] hover:text-[#0db7ff] cursor-pointer font-medium">
                More...
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
