'use client'

import { ChevronLeft, ChevronRight, Search } from 'lucide-react'

export default function Header() {
  const menuItems = ['File', 'Edit', 'Selection', 'View', '...']

  return (
    <div className="bg-[#333333] border-b border-[#464647] flex flex-col">
      {/* Menu Bar */}
      <div className="px-4 py-2 flex items-center justify-between">
        <div className="flex items-center gap-0">
          {menuItems.map((item, idx) => (
            <button
              key={idx}
              className="px-3 py-1.5 text-xs text-[#cccccc] hover:bg-[#464647] transition-colors"
            >
              {item}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-1">
          <button className="p-1.5 text-[#858585] hover:text-[#cccccc] transition-colors">
            <ChevronLeft size={18} strokeWidth={2} />
          </button>
          <button className="p-1.5 text-[#858585] hover:text-[#cccccc] transition-colors">
            <ChevronRight size={18} strokeWidth={2} />
          </button>
        </div>

        <div className="flex-1 mx-4 flex items-center bg-[#464647] rounded px-3 py-1.5">
          <Search size={14} className="text-[#858585]" />
          <input
            type="text"
            placeholder="nando-port [Administrator]"
            className="flex-1 bg-transparent ml-2 text-[#cccccc] placeholder-[#858585] outline-none text-xs py-0.5"
          />
        </div>

        <div className="flex items-center gap-0.5">
          <button className="p-1.5 text-[#858585] hover:text-[#cccccc] transition-colors">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <rect x="3" y="3" width="7" height="7" />
              <rect x="14" y="3" width="7" height="7" />
              <rect x="14" y="14" width="7" height="7" />
              <rect x="3" y="14" width="7" height="7" />
            </svg>
          </button>
          <button className="p-1.5 text-[#858585] hover:text-[#cccccc] transition-colors">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <rect x="3" y="5" width="18" height="14" rx="2" />
              <path d="M7 15V9M12 15V5M17 15V9" />
            </svg>
          </button>
          <button className="p-1.5 text-[#858585] hover:text-[#cccccc] transition-colors">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="12" cy="12" r="1" />
              <circle cx="19" cy="12" r="1" />
              <circle cx="5" cy="12" r="1" />
            </svg>
          </button>
          <button className="p-1.5 text-[#858585] hover:text-[#cccccc] transition-colors">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <line x1="18" y1="6" x2="6" y2="18" />
              <line x1="6" y1="6" x2="18" y2="18" />
            </svg>
          </button>
        </div>
      </div>
    </div>
  )
}
