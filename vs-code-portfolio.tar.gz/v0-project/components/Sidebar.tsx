'use client'

import { FileText, Search, GitBranch, Bug, Zap, Users, Settings } from 'lucide-react'
import { useState } from 'react'

export default function Sidebar() {
  const [activeIcon, setActiveIcon] = useState(0)

  const icons = [
    { icon: FileText, label: 'Explorer' },
    { icon: Search, label: 'Search' },
    { icon: GitBranch, label: 'Source Control' },
    { icon: Bug, label: 'Run & Debug' },
    { icon: Zap, label: 'Extensions' },
  ]

  return (
    <div className="w-14 bg-[#333333] border-r border-[#464647] flex flex-col items-center py-3 gap-2">
      {icons.map((item, idx) => (
        <button
          key={idx}
          onClick={() => setActiveIcon(idx)}
          className={`p-2.5 rounded transition-all ${
            activeIcon === idx
              ? 'text-[#0098ff] bg-[#0098ff]/10'
              : 'text-[#858585] hover:text-[#cccccc]'
          }`}
          title={item.label}
        >
          <item.icon size={20} strokeWidth={2} />
        </button>
      ))}
      
      <div className="flex-1" />
      
      {/* Bottom icons */}
      <div className="space-y-2 border-t border-[#464647] pt-2">
        <button className="p-2.5 rounded text-[#858585] hover:text-[#cccccc] transition-colors" title="Accounts">
          <Users size={20} strokeWidth={2} />
        </button>
        <button className="p-2.5 rounded text-[#858585] hover:text-[#cccccc] transition-colors" title="Settings">
          <Settings size={20} strokeWidth={2} />
        </button>
      </div>
    </div>
  )
}
