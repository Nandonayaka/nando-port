'use client'

export default function StatusBar() {
  return (
    <div className="bg-[#007acc] text-[#d4d4d4] text-xs px-4 py-2 flex items-center justify-between flex-shrink-0 border-t border-[#464647]">
      <div className="flex items-center gap-4">
        <label className="flex items-center gap-1.5 hover:text-white cursor-pointer transition-colors">
          <input type="checkbox" className="w-3 h-3" defaultChecked />
          <span>Show welcome page on startup</span>
        </label>
      </div>

      <div className="flex items-center gap-4">
        <button className="text-[#d4d4d4] hover:text-white transition-colors">
          ✓ main
        </button>
        <span className="text-[#d4d4d4]">◎</span>
        <button className="text-[#d4d4d4] hover:text-white transition-colors">
          0:0
        </button>
        <span className="text-[#d4d4d4]">0:0</span>
        <button className="text-[#d4d4d4] hover:text-white transition-colors">
          🟠 BLACKBOX Agent
        </button>
        <button className="text-[#d4d4d4] hover:text-white transition-colors">
          🌐 Reconnect to Discord
        </button>
        <button className="text-[#d4d4d4] hover:text-white transition-colors">
          Open Website
        </button>
        <button className="text-[#d4d4d4] hover:text-white transition-colors">
          Generate Commit Message
        </button>
        <button className="text-[#d4d4d4] hover:text-white transition-colors">
          🟡 BLACKBOX AI Open Chat
        </button>
      </div>
    </div>
  )
}
